package com.example.jemapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;

import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static android.app.Activity.RESULT_OK;
import static com.android.volley.VolleyLog.TAG;

public class perfilFragment extends Fragment implements View.OnClickListener {

    String iduser, direccionIP;
    String  apellido, nombre, dni, titulo, universidad, domicilio;
    direccionIP URL;
    private TextView textapellido, textnombre, textdni, texttitulo, textuniversidad, textdomicilio;
    private Button botonFoto, botonPass, botonMod;
    private ImageView imagen;
    private JSONArray ja;

    private static int TAKE_PICTURE = 1;
    private static int SELECT_PICTURE = 2;
    private String name = "";
    //private ArrayList<String> datos = new ArrayList<String>();
    Button buttonChoose;
   // FloatingActionButton buttonUpload;
    //Toolbar toolbar;
    ImageView imageView;
    EditText txt_name;
    Bitmap bitmap, decoded;
    int success;
    int PICK_IMAGE_REQUEST = 1;
    int bitmap_size = 60; // range 1 - 100

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    private String KEY_IMAGE = "image";
    private String KEY_NAME = "name";



    String tag_json_obj = "json_obj_req";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_perfil, container, false);
        View view = inflater.inflate(R.layout.fragment_perfil, container, false);
        iduser = getArguments().getString("iduser");
        //Toast.makeText(getActivity(),"Id Usuario: "+iduser,Toast.LENGTH_SHORT).show();
        URL=new direccionIP();
        direccionIP=URL.getIP();

        textapellido = (TextView)view.findViewById(R.id.textApellido);
        textnombre = (TextView) view.findViewById(R.id.textNombre);
        textdni = (TextView) view.findViewById(R.id.textDNI);
        texttitulo = (TextView) view.findViewById(R.id.textTitulo);
        textuniversidad = (TextView) view.findViewById(R.id.textUniversidad);
        textdomicilio = (TextView) view.findViewById(R.id.textDomicilio);

        botonFoto = (Button) view.findViewById(R.id.buttonFoto);
        botonFoto.setOnClickListener(this);
        botonPass = (Button) view.findViewById(R.id.buttonPass);
        botonPass.setOnClickListener(this);
        imagen=(ImageView) view.findViewById(R.id.foto);
        botonMod = (Button) view.findViewById(R.id.buttonMod);
        botonMod.setOnClickListener(this);
        //Toast.makeText(getApplicationContext(),"Id Usuario: "+iduser,Toast.LENGTH_SHORT).show();
        //nombre = findViewById(R.id.textNombre);
        //requestJSON();
        requestUsuario(direccionIP+"datosusuario.php?iduser="+iduser);

        return  view;

    }

    private void requestUsuario(String URL) {

        Log.i("url",""+URL);

        //RequestQueue queue = Volley.newRequestQueue(this);
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        StringRequest stringRequest =  new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    ja = new JSONArray(response);
                    DatosUsuario userData = new DatosUsuario();

                    apellido = ja.getString(1);
                    userData.setApellido(apellido);
                    nombre = ja.getString(2);
                    userData.setNombre(nombre);
                    dni = ja.getString(3);
                    userData.setDNI(dni);
                    titulo = ja.getString(4);
                    userData.setTitulo(titulo);
                    universidad = ja.getString(5);
                    userData.setUniversidad(universidad);
                    domicilio= ja.getString(8);
                    userData.setDomicilio(domicilio);

                    textapellido.setText(textapellido.getText()+userData.getApellido());
                    textnombre.setText(textnombre.getText()+ userData.getNombre());
                    textdni.setText(textdni.getText()+ userData.getDNI());
                    texttitulo.setText(texttitulo.getText()+ userData.getTitulo());
                    textuniversidad.setText(textuniversidad.getText()+userData.getUniversidad());
                    textdomicilio.setText(textdomicilio.getText()+ userData.getDomicilio());

                    //String domicilio = ja.getString(7);
                    //Toast.makeText(getApplicationContext(),"Domicilio Usuario: "+domicilio,Toast.LENGTH_SHORT).show();
                    //datos.add(domicilio);
                    //Toast.makeText(getApplicationContext(),nombre.toString(),Toast.LENGTH_LONG).show();

                } catch (JSONException e) {
                    e.printStackTrace();
                    //Toast.makeText(getApplicationContext(),"error",Toast.LENGTH_LONG).show();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(stringRequest);


    }
    @Override
    public void onClick(View v) {
        //Mostrar el diálogo de progreso
        //final ProgressDialog loading = ProgressDialog.show(this,"Subiendo...","Espere por favor...",false,false);
        switch(v.getId()) {
            case R.id.buttonFoto:
                cargarImagen();
                break;
            case R.id.buttonPass:
                cambiarPass();
                break;
            case R.id.buttonMod:
                //Toast.makeText(getApplicationContext(),"boton apretado",Toast.LENGTH_SHORT).show();
                modificarDatos();
                break;
        }

    }

    public  void cargarImagen(){
        Intent intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/");
        startActivityForResult(intent.createChooser(intent,"Seleccione"),10);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK){
            Uri path=data.getData();
            imagen.setImageURI(path);

            Toast.makeText(getActivity(),"Subir foto a la BD",Toast.LENGTH_SHORT).show();

            uploadImage();
        }
    }

     public void cambiarPass()
    {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = this.getLayoutInflater();
        View v_iew=inflater.inflate(R.layout.pass_dialog, null) ;
        builder.setView(v_iew);
        builder.setNegativeButton("CANCELAR",null);
        final EditText uName = v_iew.findViewById(R.id.EditText_Pwd1);
        final EditText uName2 = v_iew.findViewById(R.id.EditText_Pwd2);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String pass=uName.getText().toString();
                String pass2=uName2.getText().toString();

                if(!pass.equals(pass2))
                {
                    Toast.makeText(getActivity(),"Las contraseñas no coinciden",Toast.LENGTH_SHORT).show();
                    //Toast.makeText(getApplicationContext(),"Las contraseñas no coinciden",Toast.LENGTH_SHORT).show();
                }
                else{
                    String url2=direccionIP+"actualizarPass.php?iduser="+ iduser+"&pass="+pass ;
                    updateContrasenia(url2);
                }
            }
        });

        builder.create();
        builder.show();
    }

    public void updateContrasenia(String URL)
    {
        Log.i("url",""+URL);

        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        StringRequest stringRequest =  new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    Object json = new JSONObject(response);
                    //Toast.makeText(getApplicationContext(),"json:" +((JSONObject) json).get("code").toString(),Toast.LENGTH_LONG).show();
                    if(((JSONObject) json).get("code").equals(0))
                    {
                        //Toast.makeText(getApplicationContext(),"Tu contraseña se cambio exitosamente",Toast.LENGTH_LONG).show();
                        Toast.makeText(getActivity(),"Tu contraseña se cambio exitosamente",Toast.LENGTH_SHORT).show();
                        //mostrarDialogo("Te has dado de baja al curso");
                    }
                    else {
                         Toast.makeText(getActivity(),"No se pudo actualizar la contraseña",Toast.LENGTH_SHORT).show();
                        //mostrarDialogo("No puedes inscribirte al curso por que ya no hay cupo");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    //Toast.makeText(getApplicationContext(),"error",Toast.LENGTH_LONG).show();

                }
                Toast.makeText(getActivity(),"error",Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(stringRequest);

    }

    public void modificarDatos()
    {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = this.getLayoutInflater();
        View v_iew=inflater.inflate(R.layout.modificar_datos_dialog, null) ;
        builder.setView(v_iew);
        builder.setNegativeButton("CANCELAR",null);
        final EditText uApellido = v_iew.findViewById(R.id.editApellido);
        uApellido.setText(apellido);
        final EditText uNombre = v_iew.findViewById(R.id.editNombre);
        uNombre.setText(nombre);
        final EditText uDNI = v_iew.findViewById(R.id.editDNI);
        uDNI.setText(dni);
        final EditText uTitulo = v_iew.findViewById(R.id.editTitulo);
        uTitulo.setText(titulo);
        final EditText uUniversidad = v_iew.findViewById(R.id.editUniversidad);
        uUniversidad.setText(universidad);
        final EditText uDomicilio = v_iew.findViewById(R.id.editDomicilio);
        uDomicilio.setText(domicilio);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                String nvoApellido=uApellido.getText().toString();
                String nvoNombre=uNombre.getText().toString();
                String nvoDni=uDNI.getText().toString();
                String nvoTitulo=uTitulo.getText().toString();
                String nvoUniversidad=uUniversidad.getText().toString();
                String nvoDomicilio=uDomicilio.getText().toString();

                if(nvoApellido.equals("")||nvoNombre.equals("")||nvoDni.equals("")||nvoTitulo.equals("")||nvoUniversidad.equals("")||nvoDomicilio.equals(""))
                {
                    //mostrarMensaje();
                    //Toast.makeText(getApplicationContext(),"Faltan Completar Datos",Toast.LENGTH_SHORT).show();
                    Toast.makeText(getActivity(),"Faltan Completar Datos",Toast.LENGTH_SHORT).show();
                }
                else{
                    String url3=direccionIP+"modificarUsuario.php?iduser="+iduser+"&apellido="+nvoApellido+"&nombre="+nvoNombre+"&dni="+nvoDni+
                            "&titulo="+nvoTitulo+"&universidad="+nvoUniversidad+"&domicilio="+nvoDomicilio;
                    updateUsuario(url3);
                }
            }
        });
        builder.create();
        builder.show();
    }

    public void mostrarMensaje(){
        AlertDialog.Builder builder2 = new AlertDialog.Builder(getActivity());
        builder2.setTitle("Importante");
        builder2.setMessage("Faltan Completar datos");
        builder2.setPositiveButton("OK",null);
        builder2.create();
        builder2.show();
    }

    public void updateUsuario(String URL)
    {
        Log.i("url",""+URL);

        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        StringRequest stringRequest =  new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    Object json = new JSONObject(response);
                    //Toast.makeText(getApplicationContext(),"json:" +((JSONObject) json).get("code").toString(),Toast.LENGTH_LONG).show();
                    if(((JSONObject) json).get("code").equals(0))
                    {
                        Toast.makeText(getActivity(),"Los datos se actualizaron correctamente",Toast.LENGTH_SHORT).show();
                        //Intent intent = new Intent(PerfilColaborador.this, PerfilColaborador.class);
                        //intent.putExtra("iduser",iduser.toString());
                        //startActivity(intent);

                        //mostrarDialogo("Te has dado de baja al curso");
                    }
                    else {
                        //Toast.makeText(getApplicationContext(),"No se pudieron actualizar los datos",Toast.LENGTH_LONG).show();
                        Toast.makeText(getActivity(),"error",Toast.LENGTH_SHORT).show();
                        //mostrarDialogo("No puedes inscribirte al curso por que ya no hay cupo");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    //Toast.makeText(getApplicationContext(),"error",Toast.LENGTH_LONG).show();
                    Toast.makeText(getActivity(),"error",Toast.LENGTH_SHORT).show();

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(stringRequest);

    }

    private void uploadImage() {
        //menampilkan progress dialog
        //final ProgressDialog loading = ProgressDialog.show(getActivity(), "Uploading...", "Please wait...", false, false);
        String URLimg=direccionIP+"subirimagen.php?iduser="+iduser;
        Toast.makeText(getActivity(),iduser.toString(),Toast.LENGTH_SHORT).show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URLimg,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e(TAG, "Response: " + response.toString());

                        try {
                            JSONObject jObj = new JSONObject(response);
                            success = jObj.getInt(TAG_SUCCESS);

                            if (success == 1) {
                                Log.e("v Add", jObj.toString());

                                Toast.makeText(getActivity(), jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                                kosong();

                            } else {
                                Toast.makeText(getActivity(), jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //menghilangkan progress dialog
                        //loading.dismiss();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //menghilangkan progress dialog
                        //loading.dismiss();

                        //menampilkan toast
                        Toast.makeText(getActivity(), error.getMessage().toString(), Toast.LENGTH_LONG).show();
                        Log.e(TAG, error.getMessage().toString());
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                //membuat parameters
                Map<String, String> params = new HashMap<String, String>();

                //menambah parameter yang di kirim ke web servis
                //params.put(KEY_IMAGE, getStringImage(decoded));
                params.put(KEY_NAME, txt_name.getText().toString().trim());

                //kembali ke parameters
                Log.e(TAG, "" + params);
                return params;
            }
        };

        //AppController.getInstance().addToRequestQueue(stringRequest, tag_json_obj);
    }

    private void kosong() {
        imageView.setImageResource(0);
        txt_name.setText(null);
    }

    private void setToImageView(Bitmap bmp) {
        //compress image
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, bitmap_size, bytes);
        decoded = BitmapFactory.decodeStream(new ByteArrayInputStream(bytes.toByteArray()));

        //menampilkan gambar yang dipilih dari camera/gallery ke ImageView
        imageView.setImageBitmap(decoded);
    }

    // fungsi resize image
    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float) width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }
}
