package com.example.jemapp;

import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import static android.widget.Toast.LENGTH_LONG;

public class escanerAcredActivity extends AppCompatActivity {
    private TextView txtnom;
    private TextView txtdni;
    private ImageView foto;
    private Button btnCancel;
    private Button btnAceptar;
    private TextView txt7;
    inscripcionFragment mifrag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escaner_acred);

        txtnom = (TextView)findViewById(R.id.txtNombreA);
        txtdni = (TextView)findViewById(R.id.txtDniA);
        foto = (ImageView)findViewById(R.id.imgFotoA);
        btnAceptar = (Button)findViewById(R.id.button2);
        btnCancel = (Button)findViewById(R.id.btnCancelar);
        txt7 = (TextView)findViewById(R.id.textView7);
        mifrag= new inscripcionFragment();

        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
        integrator.setPrompt("Posicione el codigo QR");
        integrator.setOrientationLocked(true);
        integrator.setBarcodeImageEnabled(false);
        integrator.initiateScan();

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent voler = new Intent(Main2Activity.this, MainActivity.class);
                //startActivity(voler);
                finish();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        String linea1 = "J+E+M+19";
        String mensaje;
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(result != null) {
            if(result.getContents() == null) {
                Toast.makeText(this, "Cancelado...", LENGTH_LONG).show();

            } else {
                mensaje=result.getContents();
                if (mensaje.contains(linea1)) {

                    String auxnomb;
                    int ininb;
                    int finnb;
                    ininb = mensaje.indexOf("q1-"); //nombre persona
                    finnb = mensaje.indexOf("-q1");
                    ininb = ininb+3;
                    auxnomb = mensaje.substring(ininb,finnb);

                    String auxdni;
                    int inidni;
                    int findni;
                    inidni = mensaje.indexOf("q2-"); //dni persona
                    findni = mensaje.indexOf("-q2");
                    inidni = inidni+3;
                    auxdni = mensaje.substring(inidni,findni);

                    final String auxcp;
                    int initit;
                    int fintit;
                    initit = mensaje.indexOf("q3-"); //codigo persona
                    fintit = mensaje.indexOf("-q3");
                    initit = initit+3;
                    auxcp = mensaje.substring(initit,fintit);

                    this.txtnom.setText(auxnomb);
                    this.txtdni.setText(auxdni);
                    cargarImagen(auxcp);

                    btnAceptar.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            guardarDatos(auxcp);

                        }
                    });

                }else {
                    Toast.makeText(this, "El codigo QR no es valido", LENGTH_LONG).show();
                    //Intent volver = new Intent(Main2Activity.this, MainActivity.class);
                    //startActivity(volver);     revisar otra vezaaaaaaaa
                    finish();
                }

            }

        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }


    }

    private void cargarImagen(String auxcp) {
        //this.foto.setImageResource(R.drawable.img2);
        final Bitmap[] imgbitmap = new Bitmap[1];

        RequestQueue buscarFoto = Volley.newRequestQueue(this);
        String dire = "http://192.168.0.118/jemapp19/consultaFoto.php?id="+auxcp+"";
        StringRequest bufot = new StringRequest(Request.Method.GET, dire, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    byte [] byteCode = Base64.decode(response,Base64.DEFAULT);
                    imgbitmap[0] = BitmapFactory.decodeByteArray(byteCode,0,byteCode.length);
                    foto.setImageBitmap(imgbitmap[0]);

                } catch (Exception e){
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        buscarFoto.add(bufot);

    }


    private void guardarDatos(final String auxcp) {

        final String[] fecha = {" "};

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        String url2 ="http://192.168.0.118/jemapp19/buscarFecha.php";
        StringRequest busq = new StringRequest(Request.Method.GET, url2, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("LA FECHA ES", response);
                fecha[0] = response;
                Log.i("LO Q DEBERIA DEVOLVER",fecha[0]);
                String date = fecha[0];
                Log.i("EEE-La fecha es ", date);
                terminarGuardar(auxcp, date);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // Toast.makeText(getApplicationContext(), "Se produjo un error: "+error.toString(), LENGTH_LONG).show();
                Log.i("EEEError de la fecha", error.toString());
            }
        });
        requestQueue.add(busq);

    }

    protected void terminarGuardar(String auxcp, String date){
        Log.i("DATO1 ", auxcp);
        Log.i("DATO2 ", date);
        String auxfech = date.substring(2,21);
        Log.i("DATOAGUARDAR ", auxfech);
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String url ="http://192.168.0.118/jemapp19/registroAcred.php?id="+auxcp+"&fecha="+auxfech+"";
        url=url.replace(" ", "%20");
        StringRequest pedido = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        txt7.setText("Se realizo con éxito la acreditación");
                        //rvDatos.setVisibility(View.INVISIBLE);
                        btnAceptar.setVisibility(View.INVISIBLE);
                        btnCancel.setVisibility(View.INVISIBLE);
                        //Intent volver = new Intent(Main2Activity.this, MainActivity.class);
                        //startActivity(volver);

                        //FragmentManager fm=getFragmentManager();
                        //fm.beginTransaction().replace(R.id.escenarioColaborador,mifrag).commit();
                        //este tambien deberia ser un intent con finish
                        final FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.escenarioColaborador, new acreditacionFragment());
                        ft.addToBackStack(null);
                        ft.commit();
                    }


                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                txt7.setText("No se pudo Acreditar, verifique estado Inscripcion");
                finish();
            }
        });

        requestQueue.add(pedido);


    }
}
