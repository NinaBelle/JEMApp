package com.example.jemapp;

public class direccionIP
{
    public String getIP()
    {
        return "http://192.168.0.118/jemapp19/";
    }
}
