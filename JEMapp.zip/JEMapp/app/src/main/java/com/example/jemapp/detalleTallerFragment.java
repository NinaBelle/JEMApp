package com.example.jemapp;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class detalleTallerFragment extends Fragment implements View.OnClickListener {

    private String iduser, idtaller, turno, direccionIP;
    private direccionIP URL;
    private TextView txtNombre, txtDescripcion;
    private JSONArray ja;
    private Button BTNinscribirse;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       //return inflater.inflate(R.layout.fragment_perfil, container, false);
        View view = inflater.inflate(R.layout.fragment_detalle_taller, container, false);
        iduser = getArguments().getString("iduser");
        idtaller = getArguments().getString("idtaller");
        turno = getArguments().getString("turno");
        Toast.makeText(getActivity(),"turno: "+turno,Toast.LENGTH_SHORT).show();
        URL=new direccionIP();
        direccionIP=URL.getIP();

        txtNombre = (TextView) view.findViewById(R.id.nombreTaller);
        txtDescripcion = (TextView) view.findViewById(R.id.descripcionTaller);
        BTNinscribirse = (Button) view.findViewById(R.id.inscribirseOK);
        BTNinscribirse.setOnClickListener(this);

        requestDetalle(direccionIP+"detalletaller.php?idtaller="+idtaller.toString());

        return view;
    }

    private void requestDetalle(String URL) {

        Log.i("url",""+URL);

        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        StringRequest stringRequest =  new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    ja = new JSONArray(response);
                    String nombre = ja.getString(0);
                    String descripcion = ja.getString(1);
                    String cupo = ja.getString(2);
                    txtNombre.setText(txtNombre.getText()+ nombre);
                    txtDescripcion.setText(txtDescripcion.getText()+ descripcion);

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(),"error "+iduser,Toast.LENGTH_SHORT).show();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(stringRequest);

    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.inscribirseOK:
                Toast.makeText(getActivity(),"turno: "+turno,Toast.LENGTH_LONG).show();
                inscripcionOK(direccionIP+"inscripcion.php?iduser="+iduser+"&idtaller="+idtaller+"&turno="+turno);

        }

    }

    public void inscripcionOK(String URL)
    {
        Log.i("url",""+URL);

        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        StringRequest stringRequest =  new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    Object json = new JSONObject(response);
                    //Toast.makeText(getApplicationContext(),"json:" +((JSONObject) json).get("code").toString(),Toast.LENGTH_LONG).show();
                    if(((JSONObject) json).get("code").equals(0))
                    {
                        //Toast.makeText(getApplicationContext(),"Te has inscripto al curso",Toast.LENGTH_LONG).show();
                        mostrarDialogo("Te has inscripto al curso");

                    }
                    else {
                        if(((JSONObject) json).get("code").equals(1))
                        {
                            //Toast.makeText(getApplicationContext(),"Ya estas inscripto en este curso",Toast.LENGTH_LONG).show();
                            mostrarDialogo("Ya estas inscripto a un curso en este turno");
                        }
                        else
                        {
                            //Toast.makeText(getApplicationContext(),"No puedes inscribirte al curso xq ya no hay cupo",Toast.LENGTH_LONG).show();
                            mostrarDialogo("No puedes inscribirte al curso por que ya no hay cupo");
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(),"error",Toast.LENGTH_SHORT).show();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(stringRequest);
    }

    public void mostrarDialogo(String mensaje)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Importante");
        builder.setMessage(mensaje);
        builder.setPositiveButton("OK",null);
        builder.create();
        builder.show();
    }

}
