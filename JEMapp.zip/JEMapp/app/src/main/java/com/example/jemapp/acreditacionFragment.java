package com.example.jemapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class acreditacionFragment extends Fragment {
    private TextView txtShowTextResult;
    private Button btnAcred;
    RecyclerView rvDatos;

    String iduser;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_acreditacion, container, false);

        iduser = getArguments().getString("iduser");
        //return inflater.inflate(R.layout.fragment_acreditacion, container, false);
        txtShowTextResult = (TextView)view.findViewById(R.id.txtDisplay);
        btnAcred = (Button) view.findViewById(R.id.btnAcred);
        rvDatos = (RecyclerView) view.findViewById(R.id.rvDatos);
        //rvDatos.setHasFixedSize(true);
        // use a linear layout manager
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        rvDatos.setLayoutManager(layoutManager);

        //RequestQueue requestQueue = Volley.newRequestQueue(this);
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        String url ="http://192.168.0.118/jemapp19/consultaAcred.php";

// Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        view.findViewById(R.id.progressBar).setVisibility(View.GONE);
                        // txtShowTextResult.setText("Response is: "+response);

                        response = response.replace("][",",");
                        if (response.length()>0){
                            try {
                                JSONArray ja = new JSONArray(response);
                                Log.i("EEEEEEEElargoarray", " "+ja.length());
                                CargarListView(ja);
                            }catch (JSONException e){
                                e.printStackTrace();
                            }
                        }else {
                            view.findViewById(R.id.progressBar).setVisibility(View.GONE);
                            rvDatos.setVisibility(View.INVISIBLE);
                        }
                    }


                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                view.findViewById(R.id.progressBar).setVisibility(View.GONE);
                txtShowTextResult.setText("No hay conexion a Internet!");
                rvDatos.setVisibility(View.INVISIBLE);
            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequest);


        btnAcred.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent escanear = new Intent(getActivity(), escanerAcredActivity.class);
                startActivity(escanear);
            }
        });

        return  view;
    }

    private void CargarListView(JSONArray ja) {
        ArrayList<Acreditados> listaarreglo = new ArrayList<Acreditados>();

        for (int i=0; i<ja.length(); i+=3){
            try {
                Acreditados listado = new Acreditados(ja.getString(i),ja.getString(i+1),ja.getString(i+2));
                listaarreglo.add(listado);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        AdaptadorRv nuevo = new AdaptadorRv(listaarreglo);
        rvDatos.setAdapter(nuevo);
    }

}
