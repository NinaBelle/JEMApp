package com.example.jemapp;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import static android.widget.Toast.*;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText editPass;
    private EditText editUser;
    Button ingresar, recuperar;
    JSONArray ja;
    direccionIP URL;
    String direccionIP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        URL=new direccionIP();
        direccionIP=URL.getIP();
        editUser = (EditText) findViewById(R.id.editUsu);
        editPass = (EditText) findViewById(R.id.editContrasenia);
        ingresar=(Button) findViewById(R.id.btnLOGUIN);
        ingresar.setOnClickListener(this);
        recuperar=(Button) findViewById(R.id.btnRecuperar);
        recuperar.setOnClickListener(this);

    }

    @Override
    public void onClick(View v){
        switch(v.getId()){
            case R.id.btnLOGUIN:
                String usuario=editUser.getText().toString();
                String contrasenia=editPass.getText().toString();
                if (!usuario.equals("") && !contrasenia.equals(""))
                {
                    ConsultarUsuario(direccionIP+"consulta.php?user="+usuario+"&pass="+contrasenia);

                }
                else
                {
                    makeText(this, "Faltan completar datos", LENGTH_SHORT).show();

                }
                break;
            case R.id.btnRecuperar:
                Intent intentR = new Intent (v.getContext(), RecuperarPass.class);
                startActivityForResult(intentR, 0);
        }

    }

    private void ConsultarUsuario(String URL) {


        Log.i("url",""+URL);
        //Toast.makeText(this, "Paso x aca", Toast.LENGTH_SHORT).show();
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest stringRequest =  new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    ja = new JSONArray(response);
                    String user = ja.getString(1);
                    String pass = ja.getString(2);

                    //Toast.makeText(getApplicationContext(),"Paso por aca",Toast.LENGTH_SHORT).show();

                    if(user.equals(editUser.getText().toString())&& pass.equals(editPass.getText().toString()))
                    {

                        String tipouser = ja.getString(4);
                        String iduser =  ja.getString(0);


                        if (tipouser.equals("1"))
                        {
                            //Toast.makeText(getApplicationContext(),"Bienvenido Organizador",Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MainActivity.this, menuOrganizadorActivity.class);
                            intent.putExtra("iduser", iduser.toString());
                            intent.putExtra("tipouser", tipouser.toString());
                            startActivity(intent);

                        }
                        else{
                            if (tipouser.equals("2"))
                            {
                                // makeText(getApplicationContext(),"Bienvenido Colaborador", LENGTH_SHORT).show();
                                Intent intent = new Intent(MainActivity.this, menuColaboradorActivity.class);
                                intent.putExtra("iduser",iduser.toString());
                                intent.putExtra("tipouser", tipouser.toString());
                                startActivity(intent);
                            }
                            else
                            {
                                makeText(getApplicationContext(),"Bienvenido Asistente", LENGTH_SHORT).show();
                                Intent intent = new Intent(MainActivity.this, menuAsistenteActivity.class);
                                intent.putExtra("iduser",iduser.toString());
                                intent.putExtra("tipouser", tipouser.toString());
                                startActivity(intent);
                            }
                        }


                    }else{
                        makeText(getApplicationContext(),"verifique su contraseña", LENGTH_SHORT).show();

                    }

                } catch (JSONException e) {
                    e.printStackTrace();

                    makeText(getApplicationContext(),"El usuario no existe en la base de datos", LENGTH_LONG).show();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(stringRequest);    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
